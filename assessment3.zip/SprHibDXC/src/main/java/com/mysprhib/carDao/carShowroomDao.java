package com.mysprhib.carDao;




	import java.util.ArrayList;

	import javax.transaction.Transactional;

	import org.hibernate.Query;
	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Component;

	import com.mysprhib.model.Car;

	@Component
	public class carShowroomDao {

		@Autowired
		SessionFactory sessionFactory;
		
		@Transactional
		public void saveCar(Car car){	
		Session session=	sessionFactory.getCurrentSession();
		session.save(car);
		}

		
		@Transactional
		public  ArrayList<Car> getCars()
		{
		Session session=sessionFactory.getCurrentSession();
		ArrayList<Car> cars=(ArrayList<Car>)session.createQuery("from Car").list();	
		return cars;
		
		}
		
				
		@Transactional
		public  Car getCar(String name)
		{
		Session session=sessionFactory.getCurrentSession();
		Car car=(Car) session.get(Car.class, name);	
		return car;
		}
		
		
		
		@Transactional
		public String deleteCar(String name){	
		Session session=	sessionFactory.getCurrentSession();
		Car car=(Car) session.get(Car.class, name);
		session.delete(car);
		return "car Deleted";
		}
		
		@Transactional
		public void updateCar(Car car){	
		Session session=	sessionFactory.getCurrentSession();
		session.update(car);
		}
		
		
		public carShowroomDao(SessionFactory sessionFactory) {
			super();
			this.sessionFactory = sessionFactory;
		}
		
		
		public carShowroomDao() {
			}
		
		
	}
