package com.mysprhib.demo;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysprhib.carDao.carShowroomDao;
import com.mysprhib.model.Car;

@Controller
public class HomeController {
	
	
	@Autowired
	carShowroomDao carshowroomDao;
	
	@RequestMapping(value = "/")
	public String home(Locale locale, Model model) {
		return "home";
	}
	
	@RequestMapping(value = "/saveCar")
	public String saveCar(@ModelAttribute Car car) {
		carshowroomDao.saveCar(car);
		return "home";
	}
	
	@RequestMapping(value = "/deleteCar")
	public String deletepage(Locale locale, Model model) {
		return "delete";
	}
	
	@RequestMapping(value = "/delete")
	public String deleteRest(@RequestParam String name) {
		carshowroomDao.deleteCar(name);
		return "home";
	}
	
	@RequestMapping(value = "/disp") 
    public String search(Model model, @ModelAttribute Car cars)
  {
    ArrayList<Car> carList =  carshowroomDao.getCars();
    model.addAttribute("cars",carList); 
    System.out.println(carList);
    return "display"; 
    }

	
	
	
	
	
	  @RequestMapping(value = "/displaybyid") 
	  public String searchbyid(Model model, @RequestParam String name) 
	  { Car res = carshowroomDao.getCar(name); model.addAttribute("rn",res ); return
	  "displaybyid"; }
	 
	
	
	@RequestMapping(value = "/updateCar")
	public String updatepage(Locale locale, Model model) {
		return "update";
	}
	
	@RequestMapping(value = "/update")
	public String updateCar(@ModelAttribute Car car) {
		carshowroomDao.updateCar(car);
		return "home";
	} 
}


