package com.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;



import com.jdbc.dbutil.Dbconn;
import com.jdbc.pojo.Employee;

public class EmployeeDao {

public  String saveEmployee(Employee employee)
{
try
{
Connection con=Dbconn.getConnection();

String sql="insert into employee values(?,?,?,?)";

PreparedStatement stat=con.prepareStatement(sql);


stat.setString(1, employee.getName());
stat.setString(2, employee.getLastName());
stat.setString(3, employee.getEmpId());
stat.setString(4, employee.getAddress());


int res= stat.executeUpdate();
if(res>0)
return "Employee details saved";


}
catch (Exception e) {
e.printStackTrace();
}

return "Cannot save Employee details";

}
}

